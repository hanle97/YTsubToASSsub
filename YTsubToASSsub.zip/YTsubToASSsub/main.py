#Lay file sub copy tu Youtube
path = r"C:\Users\DELL\Desktop\test.txt"
my_file = open(path)
string_list = my_file.readlines()
my_file.close()
newfile = " ".join(string_list).strip()
new_string_list = list(newfile.splitlines())
#print(newfile)



start_time_list = [] #list thoi gian bat dau dialogue
dialogue_list = [] #list loi thoai


for x in range(len(new_string_list)):
    if x % 2 == 0: #dong le -> list thoi gian, dong chan -> list dialogue
        start_time_list.append(new_string_list[x])
    else: dialogue_list.append(new_string_list[x])


# Lay seconds trong start time de tao end time cua dialogue
seconds_modify_end = []
for x in range(len(start_time_list)):
    seconds_modify_end.append(start_time_list[x][-2:])


#list end time dialogue
end_time_list = []
for x in range(len(start_time_list)):
    if x + 1 < len(start_time_list):
        #end_time_mod = str(int(seconds_modify_end[x+1]) - 1) + ".8" (dong de can chinh timing thoi ma thay ko can lam)
        end_time = start_time_list[x + 1]
    end_time_list.append(start_time_list[x].replace(seconds_modify_end[x], end_time))


#text lay theo template cua file tao boi Aegisub, noi chung phai theo template nay Aegisub no moi doc dc
txt_layout1 = "[Events] \n Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
txt_layout2 = "Dialogue: 0,{},{},Default,,0,0,0,,{} \n"


output_list = []
for x in range(len(start_time_list)):
    finish_txt_line = txt_layout2.format(start_time_list[x], end_time_list[x], dialogue_list[x])
    output_list.append(finish_txt_line)

#print(dialogue_txt_list)

final_output = txt_layout1 + "".join(output_list)
#print(final_txt)
f = open("sub.ass", "w")
with open("sub.ass", "w") as f:
    f.write(final_output)